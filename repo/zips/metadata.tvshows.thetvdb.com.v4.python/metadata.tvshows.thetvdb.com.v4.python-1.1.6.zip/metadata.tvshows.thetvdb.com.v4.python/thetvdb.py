from resources.lib import actions, exception_logger

with exception_logger.log_exception():
    actions.run()
